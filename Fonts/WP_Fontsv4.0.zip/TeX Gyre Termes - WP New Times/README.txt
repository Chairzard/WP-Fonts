This is a modified version of TeX Gyre Termes. The full list of font files in this modified work can be found in the included MANIFEST.txt file. The original authors are not responsible for support or error reporting for this version.

Any issues with this font may be reported at https://github.com/Chairzard/WP-Fonts.

WP New Times is distributed under the GUST Font License (GFL) version 1.0.

(c) 2026 Winston Payne/Chairzard (https://github.com/Chairzard/WP-Fonts).