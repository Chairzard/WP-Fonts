The TeX Gyre font collection defines versions of the base 35 PostScript
fonts with greatly extended glyph collections. The original fonts are
the base35 release from URW.

Home page: http://www.gust.org.pl/projects/e-foundry/tex-gyre

License: GUST Font License (an instance of the LaTeX Project Public License)
http://www.gust.org.pl/fonts/licenses/GUST-FONT-LICENSE.txt
